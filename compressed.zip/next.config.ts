import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  output: "export",
  distDir: "out",
  images: {
    unoptimized: true, // nextJs optimizes images, a problem for gh pages. Tells it to render them normally
  },
  trailingSlash: true,
  basePath: "/rock-spheres-site",
};

export default nextConfig;
